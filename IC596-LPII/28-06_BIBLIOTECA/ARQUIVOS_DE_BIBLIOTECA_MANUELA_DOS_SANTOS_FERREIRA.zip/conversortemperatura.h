#ifndef CONVERSORTEMPERATURA_H
#define CONVERSORTEMPERATURA_H

float celsiusToKelvin(float t);
float kelvinToCelsius(float t);

#endif