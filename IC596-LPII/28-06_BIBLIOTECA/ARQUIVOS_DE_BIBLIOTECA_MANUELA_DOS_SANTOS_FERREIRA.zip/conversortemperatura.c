#include "conversortemperatura.h"

float celsiusToKelvin(float t) {
    return t + 273.15;
}

float kelvinToCelsius(float t) {
    return t - 273.15;
}
