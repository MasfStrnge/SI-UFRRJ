#ifndef CALCULADOR_FATORIAL_H
#define CALCULADOR_FATORIAL_H

int fatorial_laco(int numero);
int fatorial_recursivo(int numero);

#endif